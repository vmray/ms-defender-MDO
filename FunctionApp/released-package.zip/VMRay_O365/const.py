"""
constant File
"""

# pylint: disable=invalid-name

from collections import namedtuple
from dataclasses import dataclass, field
from enum import Enum
from json import loads
from os import environ

from .state_manager import StateManager

state = StateManager(environ.get("AzureWebJobsStorage"))
REMOVE_SPECIAL_CHAR = r'[^A-Za-z0-9.]'



def str_to_bool(value: str) -> bool:
    """
    Convert string to bool type
    """
    return loads(value.strip().lower()) if isinstance(value, str) else bool(value)

def format_iso8601_days(days: int) -> str:
    if days == 1:
        return "PT24H"
    return f"P{days}D"


IndicatorConfig = namedtuple(
    "IndicatorConfig",
    [
        "ACTIVE",
        "DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_IP_URL",
        "DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_IP_URL",
        "DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_FILE",
        "DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_FILE",
        "INDICATOREXPIRATION",
        "INDICATOR_ALERT",
        "TITLE",
        "DESCRIPTION",
        "MAX_TI_INDICATORS_PER_REQUEST",
    ],
)


@dataclass
class GeneralConfig:
    """
    GeneralConfig
    """

    INDICATOR_VERDICTS: list[str]


GENERAL_CONFIG = GeneralConfig(
    INDICATOR_VERDICTS=[
        verdict.lower()
        for verdict in environ.get(
            "VmraySampleVerdict", "Malicious & Suspicious"
        ).split(" & ")
    ],
)


@dataclass
class VMRayConfig:
    """
    VMRay Configuration
    """

    API_KEY: str
    URL: str
    ANALYSIS_JOB_TIMEOUT: int
    RESUBMIT: int
    VMRay_API_RETRIES: int
    VMRay_API_TIMEOUT: int
    VMRAY_INCIDENT_TAGS: bool
    VMRAY_INCIDENT_COMMENTS: bool = False
    ALERT_ID_TAGS: bool = False
    TIME_SPAN = 86400
    CONNECTOR_NAME: str = "MDOConnector"
    API_KEY_TYPE: str = "REPORT"
    SSL_VERIFY: bool = True
    SUBMISSION_COMMENT: str = (
        "Sample from VMRay Analyzer - Microsoft Defender for o365 Connector"
    )
    ANALYSIS_TIMEOUT: int = 120
    RESUBMISSION_VERDICTS: list[str] = field(
        default_factory=lambda: ["malicious", "suspicious", "clean"]
    )
    ANALYZE_ALERTS_FOR_ATTACHMENTS: list[str] = field(
        default_factory=lambda: ["Email reported by user as junk", "Email reported by user as malware or phish", "malicious email detected"]
    )


VMRay_CONFIG = VMRayConfig(
    API_KEY=environ.get("VmrayAPIKey"),
    URL=environ.get("VmrayBaseURL"),
    ANALYSIS_JOB_TIMEOUT=int(environ.get("VmrayAnalysisJobTimeout", 30)) * 60,
    RESUBMIT=environ.get("VmrayResubmitAfter", 7),
    VMRay_API_RETRIES=int(environ.get("VmrayApiMaxRetry", 5)),
    VMRay_API_TIMEOUT=int(environ.get("VmrayAPIRetryTimeout", 5)) * 60,
    VMRAY_INCIDENT_TAGS=str_to_bool(environ.get("AddTagsToIncident")),
    VMRAY_INCIDENT_COMMENTS=str_to_bool(environ.get("AddCommentsToIncident", "False")),
    ALERT_ID_TAGS=str_to_bool(environ.get("AddAlertIdTags", "False")),
)


@dataclass
class APIConfig:
    """
    Microsoft API Configurations
    """

    TENANT_ID: str
    APPLICATION_ID: str
    APPLICATION_SECRET: str
    DEFENDER_API_TIMEOUT: int
    DEFENDER_API_RETRY: int
    AUTH_URL: str
    AUTH_SEC_URL: str
    MINIMUM_ALERT_AGE: int
    ANALYZE_URP_ATTACHMENTS: bool
    LOOKBACK_EMAIL_DAYS: str
    URL_EXCLUSION_REGEX: str = ""
    ALERTS_TO_PROCESS: list[str] = field(
        default_factory=lambda: [severity.strip().lower() for severity in environ.get("AlertsSeverity", "informational, low, medium, high").split(",")]
    )
    APPLICATION_NAME: str = "VMRayDefenderForOfficeConnectorApp"
    RESOURCE_APPLICATION_ID_URI: str = "https://api.securitycenter.microsoft.com"
    SOURCE_GRAPH_API: str = "https://graph.microsoft.com/v1.0/"
    SECURITY_GRAPH_API: str = "https://graph.microsoft.com/v1.0/security"
    URL: str = "https://api.securitycenter.microsoft.com"
    USER_AGENT: str = "MDOConnector"



DEFENDER_API = APIConfig(
    TENANT_ID=environ.get("AzureTenantID", ""),
    APPLICATION_ID=environ.get("AzureClientID", ""),
    APPLICATION_SECRET=environ.get("AzureClientSecret", ""),
    DEFENDER_API_TIMEOUT=int(environ.get("DefenderApiRetryTimeout", 5)) * 60,
    DEFENDER_API_RETRY=int(environ.get("DefenderApiMaxRetry", 2)),
    AUTH_URL=f"https://login.microsoftonline.com/{environ.get('AzureTenantID', '')}/oauth2/v2.0/token",
    AUTH_SEC_URL=f"https://login.microsoftonline.com/{environ.get('AzureTenantID', '')}/oauth2/token",
    MINIMUM_ALERT_AGE=int(environ.get("MinimumAlertAge", 5)),
    URL_EXCLUSION_REGEX=environ.get("URLExclusionRegex", ""),
    ANALYZE_URP_ATTACHMENTS=str_to_bool(environ.get("AnalyzeURPAttachments", "False")),
    LOOKBACK_EMAIL_DAYS=format_iso8601_days(int(environ.get("LookbackEmailDays", "1"))),


)

INDICATOR = IndicatorConfig(
    ACTIVE=str_to_bool(environ.get("CreateIndicatorsInDefender", "True")),
    DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_IP_URL=environ.get(
        "DefenderIndicatorActionForMaliciousIPAddressURL"
    ),
    DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_IP_URL=environ.get(
        "DefenderIndicatorActionForSuspiciousIPAddressURL"
    ),
    DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_FILE=environ.get(
        "DefenderIndicatorActionForMaliciousFile"
    ),
    DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_FILE=environ.get(
        "DefenderIndicatorActionForSuspiciousFile"
    ),
    INDICATOREXPIRATION=environ.get("IndicatorExpirationInDays"),
    INDICATOR_ALERT=str_to_bool(environ.get("DefenderIndicatorAlert", "False")),
    TITLE="VMRay indicator",
    DESCRIPTION="VMRay indicator",
    MAX_TI_INDICATORS_PER_REQUEST=500,
)


class EnrichmentSectionTypes(Enum):
    """
    VMRay section to enrich
    """

    CLASSIFICATIONS = "classifications"
    THREAT_NAMES = "threat_names"
    VTIS = "vtis"


class EDREnrichment(Enum):
    """
    EDR alert ingestion
    """

    ACTIVE = True
    SELECTED_SECTIONS = ["classiIngestionConfigfications", "threat_names", "vtis"]


class AVEnrichment(Enum):
    """
    Antivirus alert ingestion
    """

    ACTIVE = True
    SELECTED_SECTIONS = ["classifications", "threat_names", "vtis"]


class JobStatus(Enum):
    """
    Job Status
    """

    INWORK = "inwork"


IOC_FIELD_MAPPINGS = {
    "ipv4": ["IpAddress"],
    "sha256": ["FileSha256"],
    "domain": ["DomainName"],
    "sha1": ["FileSha1"],
    "md5": ["FileMd5"],
    "url": ["Url"],
}

MS_DEFENDER_SEVERITY_MAPPING = {
    "malicious": "High",
    "suspicious": "Medium",
    "clean": "Informational",
}

# Define the priority order (Lower number = Higher priority)
MS_ALERTS_PRIORITY_MAPPING = {
        "high": 0,
        "medium": 1,
        "low": 2,
        "informational": 3
    }

RETRY_STATUS_CODE = [500, 501, 502, 503, 504, 429]
AUTH_ERROR_STATUS_CODE = 401