"""
Microsoft Defender Class
"""

from base64 import b64encode
import base64
from cmath import log
from datetime import datetime, timedelta, timezone
import hashlib
from io import BytesIO
from json import JSONDecodeError, dumps
from time import sleep
from typing import List, Optional

import re

import requests

from ..const import (
    AUTH_ERROR_STATUS_CODE,
    DEFENDER_API,
    INDICATOR,
    IOC_FIELD_MAPPINGS,
    RETRY_STATUS_CODE,
    EnrichmentSectionTypes,
    state,
    REMOVE_SPECIAL_CHAR,
    VMRay_CONFIG,
    MS_ALERTS_PRIORITY_MAPPING
)
from .Models import Evidence, Indicator

# pylint: disable=line-too-long
# pylint: disable=consider-using-f-string


class MicrosoftDefender:
    """
    Wrapper class for Microsoft Defender for Endpoint API calls
    Import this class to retrieve alerts, evidences and start live response jobs
    """

    def __init__(self, log):
        """
        Initialize and authenticate the MicrosoftDefender instance,
        use MicrosoftDefenderConfig as configuration
        :param log: logger instance
        :return: void
        """
        self.access_token = None
        self.headers = None
        self.graph_headers = None
        self.config = DEFENDER_API
        self.log = log
        self._incident_comment_cache = {}
        self.authenticate_graph()
        self.authenticate()

    def authenticate(self):
        """
        Authenticate using Azure Active Directory application properties,
        and retrieves the access token
        :raise: Exception when credentials/application properties are not properly configured
        :return: void
        """

        body = {
            "resource": self.config.RESOURCE_APPLICATION_ID_URI,
            "client_id": self.config.APPLICATION_ID,
            "client_secret": self.config.APPLICATION_SECRET,
            "grant_type": "client_credentials",
        }
        try:
            response = self.retry_request(
                method="POST", url=self.config.AUTH_SEC_URL, data=body, auth=True
            )
            data = response.json()
            self.access_token = data["access_token"]
            self.headers = {
                "Authorization": "Bearer %s" % self.access_token,
                "User-Agent": self.config.USER_AGENT,
                "Content-Type": "application/json",
            }
            self.log.info(
                "Successfully authenticated the Microsoft Defender for Endpoint API"
            )
        except Exception as err:
            self.log.error(err)
            raise

    def authenticate_graph(self):
        """
        Authenticate using Azure Active Directory application properties,
        and retrieves the access token
        :raise: Exception when credentials/application properties are not properly configured
        :return: void
        """

        body = {
            "client_id": self.config.APPLICATION_ID,
            "scope": "https://graph.microsoft.com/.default",
            "client_secret": self.config.APPLICATION_SECRET,
            "grant_type": "client_credentials",
        }
        try:
            response = self.retry_request(
                method="POST", url=self.config.AUTH_URL, data=body, auth=True
            )
            data = response.json()
            self.access_token = data["access_token"]
            self.graph_headers = {
                "Authorization": "Bearer %s" % self.access_token,
                "User-Agent": self.config.USER_AGENT,
                "Content-Type": "application/json",
            }
            self.log.info(
                "Successfully authenticated the Microsoft Defender for Office365"
            )
        except Exception as err:
            self.log.error(err)
            raise

    def get_mdo_urls(self, alert_id: str) -> list:
        """
        Fetch MDO alert evidence
        alert_id: Alert ID of the alert.
        """
        query = dumps(
            {
                "Query": f"let alertId='{alert_id}'; let Msg=AlertEvidence | "
                f"where AlertId == alertId and isnotempty(NetworkMessageId) | "
                f"distinct NetworkMessageId, AlertId; let FromEvidence=AlertEvidence | "
                f"where AlertId == alertId and EntityType == 'Url' and isnotempty(RemoteUrl) | "
                f"project Timestamp, AlertId, Source='AlertEvidence', Url=RemoteUrl;"
                f" let FromClicks=UrlClickEvents | join kind=inner (Msg) on NetworkMessageId | "
                f"extend chain=todynamic(column_ifexists('UrlChain', dynamic(null))) | "
                f"project Timestamp, AlertId, Source='UrlClickEvents', Url, FinalUrl=iif(isnull(chain)"
                f" or array_length(chain)==0, Url, tostring(chain[array_length(chain)-1]));"
                f" let FromEmail=EmailUrlInfo | join kind=inner (Msg) on NetworkMessageId | "
                f"project Timestamp, AlertId, Source='EmailUrlInfo', Url, FinalUrl=Url; "
                f"union FromEvidence, FromClicks, FromEmail | "
                f"summarize FirstSeen=min(Timestamp) by AlertId, Source, Url, FinalUrl | order by FirstSeen desc",
                "Timespan": "PT24H",
            }
        )
        request_url = f"{self.config.SECURITY_GRAPH_API}/runHuntingQuery"
        try:
            max_attempts = DEFENDER_API.DEFENDER_API_RETRY
            attempt = 0
            results = []

            while attempt < max_attempts:
                attempt += 1
                if attempt > 1:
                    query = query.replace("PT24H", self.config.LOOKBACK_EMAIL_DAYS)
                    self.log.info(
                        "Retrying with extended timespan %s",
                        self.config.LOOKBACK_EMAIL_DAYS
                    )
                response = self.retry_request(
                    method="POST",
                    url=request_url,
                    headers={**self.graph_headers},
                    data=query,
                )

                try:
                    results = response.json().get("results", [])
                except (JSONDecodeError, ValueError) as e:
                    self.log.warning("JSON error on attempt %d: %s", attempt, e)
                    results = []

                if results:
                    break

                if attempt <= max_attempts:
                    self.log.info(
                        "No results (attempt %d/%d). Retrying in 60s...",
                        attempt,
                        max_attempts,
                    )
                    sleep(60)

            # Final failure
            if not results:
                self.add_comment_to_alert(alert_id, "No Url Found")

            self.log.info("length of results urls %d", len(results))
            urls = {
                item.get("Url")
                for item in results
                if isinstance(item, dict) and item.get("Url")
            }
            return list(urls)

        except Exception as err:
            self.log.error("Exception while retrieving alert %s: %s", alert_id, err)
            return []
        
    def get_alerts_from_defender(self, last_run):
        """
        Retrieve alerts and related evidence information
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/get-alerts
        :exception: when alerts and evidences are not properly retrieved
        :return raw_alerts: list of raw alert dict
        """
        odata_query = f"$filter=serviceSource eq 'microsoftDefenderForOffice365' and createdDateTime ge {last_run}"
        request_url = f"{self.config.SECURITY_GRAPH_API}/alerts_v2?{odata_query}"
        updated_last_run = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        try:
            response = self.retry_request(
                method="GET", url=request_url, headers=self.graph_headers
            )
            json_response = response.json()

            if not json_response:
                self.log.error(
                    "Failed to parse api response - Error: value key not found in dict."
                )
                return []

            if "error" in json_response:
                self.log.error(
                    "Failed to retrieve alerts - Error: %s"
                    % json_response["error"]["message"]
                )
                return []
            state.post(updated_last_run)
            self.log.info(f"updating last run to {updated_last_run}")

            raw_alerts = json_response.get("value", [])

            if not raw_alerts:
                self.log.info("No new alerts retrieved from Microsoft Defender.")
                return []
            
            #filter alerts by severity based on configuration, if ALERTS_TO_PROCESS is configured, only process alerts with severity in the list, otherwise process all alerts
            if self.config.ALERTS_TO_PROCESS:
                raw_alerts = [alert for alert in raw_alerts if alert.get("severity", "").lower() in self.config.ALERTS_TO_PROCESS]

            #sort by seveirity to process high severity alerts first
            raw_alerts = self.sort_by_severity(raw_alerts)
            self.log.info("%d alerts are fetched" % len(raw_alerts))
            self.log.info("Alert IDs are: %s", ", ".join([alert.get("id") for alert in raw_alerts]))
            return raw_alerts

        except Exception as err:
            self.log.error("Exception while retrieving alert %s", err)
            return []
        

    def get_evidences(self, raw_alerts):
        """
        Retrieve alerts and related evidence information
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/get-alerts
        :exception: when alerts and evidences are not properly retrieved
        :return evidences: dict of Evidence objects, key is either url or file sha256 depending on the entity type
        """
       
        evidences: dict = {}
        try:

            exclusion_list = self.build_url_exclusion_patterns(self.config.URL_EXCLUSION_REGEX)

            for raw_alert in raw_alerts:
                if self.config.ANALYZE_URP_ATTACHMENTS:
                    attachments = self.get_attachments_from_mailbox(raw_alert)
                    for attachment in attachments:
                        file_evidence_obj = self.process_attachment(attachment)
                        if not file_evidence_obj:
                            continue
                        file_obj, sha256_val = file_evidence_obj
                        evidence_obj = evidences.get(sha256_val) or Evidence(
                            alert_id=raw_alert["id"],
                            incident_id=raw_alert["incidentId"],
                            entity_type="File",
                            file=file_obj,
                            sha256=sha256_val,
                        )
                        evidence_obj.alert_ids.add(raw_alert["id"])
                        evidence_obj.set_comments(raw_alert.get("comments", []))
                        evidences[sha256_val] = evidence_obj
                        yield evidence_obj

                self.wait_for_alert_mature(raw_alert)
                url_list = self.get_mdo_urls(raw_alert.get("id"))
                for url in url_list:
                    passed_url = self.filter_url(url, exclusion_list)
                    if not passed_url:
                        self.log.info("URL %s is excluded by exclusion regex.", url)
                        continue
                    evidence_obj = evidences.get(url) or Evidence(
                        alert_id=raw_alert["id"],
                        incident_id=raw_alert["incidentId"],
                        url=url,
                        entity_type="Url",
                    )
                    evidence_obj.alert_ids.add(raw_alert["id"])
                    evidence_obj.set_comments(raw_alert.get("comments", []))
                    evidences[url] = evidence_obj
                    yield evidence_obj
            
        except Exception as err:
            self.log.error("Exception while retrieving alert %s", err)

    
    def get_attachments_from_mailbox(self, alert_obj) -> list:
        
        if not alert_obj:
            self.log.error("Alert object is None.")
            return []
        alert_id = alert_obj.get("id")
        self.log.info(f"Retrieving attachments for alert {alert_id}")
        if not alert_obj.get("title") in VMRay_CONFIG.ANALYZE_ALERTS_FOR_ATTACHMENTS:
            self.log.info(f"Alert {alert_id} with title '{alert_obj.get('title')}' is not in the list of titles to analyze for attachments, skipping mailbox retrieval.")
            return []
        if not alert_obj.get("evidence"):
            return []
        target_type = "#microsoft.graph.security.analyzedMessageEvidence"
        message_evidences = [
            item for item in alert_obj.get("evidence", [])
            if item.get("@odata.type") == target_type
        ]
        # Assuming there's only one analyzedMessageEvidence per alert, which is usually the case for email alerts
        if not message_evidences:
            self.log.warning(f"No analyzedMessageEvidence found for alert {alert_id}, cannot retrieve attachments.")
            return []
        # if len(message_evidences) > 1:
        #     self.log.warning(f"Multiple analyzedMessageEvidence found for alert {alert_id}, using the first one.")
        # message_evidence = message_evidences[0]


        # check this case in prod, if attachmentsCount is 0 but there are evidences of type analyzedMessageEvidence, we might miss some attachments if we return early here, need to call mailbox API to double check
        # attachmentsCount = message_evidence.get("attachmentsCount", 0)
        # self.log.info(f"Found {attachmentsCount} attachments for alert {alert_id}")
        # if not attachmentsCount:
        #     return []

        all_attachments = []
        for evidence in message_evidences:
            mail_username = evidence.get("recipientEmailAddress")
            internetMessageId = evidence.get("internetMessageId")
            if not internetMessageId.startswith("<") and not internetMessageId.endswith(">"):
                internetMessageId = f"<{internetMessageId}>"
            if not mail_username or not internetMessageId:
                self.log.warning(f"Missing recipientEmailAddress or internetMessageId in analyzedMessageEvidence for alert {alert_id}, cannot retrieve attachments.")
                continue
            all_attachments.extend(self.call_mail_attachments(mail_username, internetMessageId))
        return all_attachments
        


    def call_mail_attachments(self, mail_username, internetMessageId) -> list:
        """
        Retrieve email attachments via Microsoft Graph API using recipient email and internet message ID
        """
        self.log.info(f"Retrieving attachments from mailbox for user {mail_username} and message ID {internetMessageId}")
        # Graph API endpoint to get messages with a specific internetMessageId for a user
        request_url = f"{self.config.SOURCE_GRAPH_API}/users/{mail_username}/messages?$filter=internetMessageId eq '{internetMessageId}'&$expand=attachments"
        try:
            response = self.retry_request(
                method="GET",
                url=request_url,
                headers=self.graph_headers,
            )
            if response.status_code != 200:
                self.log.error(
                    "Failed to retrieve message for user %s - Error: %s"
                    % (mail_username, response.reason)
                )
                return []
            messages = response.json().get("value", [])
            if not messages:
                self.log.warning(f"No messages found for user {mail_username}")
                return []
            # Assuming the internetMessageId is unique, we take the first message returned
            message = messages[0]
            attachments = message.get("attachments", [])
            self.log.info(f"Found {len(attachments)} attachments for user {mail_username}: {[a.get('name') for a in attachments]}")
            return attachments
        except Exception as err:
            self.log.error(
                "Failed to retrieve attachments from mailbox for user %s - Error: %s"
                % (mail_username, err)
            )
            return []
        
    def process_attachment(self, attachment) -> Optional[tuple]:
        """
        Decodes attachment, creates an in-memory file, and calculates SHA256.
        Returns: (BytesIO_object, sha256_hex)
        """
        # 1. Decode
        try:
            if "image/" in attachment.get("contentType", "").lower():
                self.log.info(f"Skipping image attachment {attachment.get('name')}")
                return None
            raw_bytes = base64.b64decode(attachment.get("contentBytes", ""))
            if not raw_bytes:
                self.log.warning(f"Attachment {attachment.get('name')} has no content after decoding.")
                return None
            
            # 2. Hash
            sha256_val = hashlib.sha256(raw_bytes).hexdigest()
            
            # 3. Create File Object
            file_obj = BytesIO(raw_bytes)
            file_obj.name = attachment.get("name") # Helpful for downstream libraries
            
            return file_obj, sha256_val
        except Exception as err:
            self.log.error(f"Failed to process attachment {attachment.get('name')} - Error: {err}")
            return None

    def sort_by_severity(self, data_list):
        """Sort a list of alerts by severity using the predefined priority mapping.
        Alerts with severity not in the mapping will be treated as lowest priority.
        """
        
        # Sort using the map; .get() handles missing keys by giving them a high number
        return sorted(data_list, key=lambda x: MS_ALERTS_PRIORITY_MAPPING.get(x['severity'].lower(), 99))


    def build_url_exclusion_patterns(self, setting: str) -> List["re.Pattern"]:
        """
        Parse the URLExclusionRegex app setting into a list of compiled patterns.

        The setting is a comma separated list of regular expressions. Each entry
        is stripped of surrounding whitespace, because a pattern such as
        " .*\\.example\\.com" would otherwise require a literal leading space and
        could never match a URL.

        An invalid pattern is logged and skipped so that one bad entry cannot
        stop the remaining patterns, or the alert processing, from working.

        :param setting: raw value of the URLExclusionRegex app setting
        :return: list of compiled regex patterns, may be empty
        """
        patterns: List["re.Pattern"] = []

        for raw_pattern in (setting or "").split(","):
            pattern = raw_pattern.strip()
            if not pattern:
                continue
            try:
                patterns.append(re.compile(pattern, re.IGNORECASE))
            except re.error as err:
                self.log.error(
                    "Invalid URL exclusion pattern %s - it will be ignored. Error: %s",
                    repr(pattern),
                    err,
                )

        if patterns:
            self.log.info("%d URL exclusion pattern(s) loaded", len(patterns))

        return patterns

    def filter_url(self, url: str, exclusion_regex: List["re.Pattern"]) -> Optional[str]:
        """
        Return the URL only if it does NOT match any exclusion regex.
        Otherwise, return None.
        """
        for pattern in exclusion_regex:
            if pattern.search(url):
                return None
        return url

    
    def wait_for_alert_mature(self, alert_obj):
        """
        Wait until the alert reaches the minimum age required for reliable evidence retrieval.
        """
        alert_id = alert_obj.get("id")
        alert_created = alert_obj.get("createdDateTime")

        if not alert_created:
            self.log.warning(
                "Alert %s does not contain createdDateTime. Skipping maturity wait.",
                alert_id,
            )
            return

        try:
            alert_creation_time = datetime.fromisoformat(
                alert_created.replace("Z", "+00:00")
            )

            now_utc = datetime.now(timezone.utc)
            elapsed_minutes = (now_utc - alert_creation_time).total_seconds() / 60

            min_age = self.config.MINIMUM_ALERT_AGE

            if elapsed_minutes >= min_age:
                return

            self.log.info("Minimum alert age is set to %d minutes", min_age)
            wait_minutes = max(min_age - elapsed_minutes, 0)


            self.log.info(
                "Alert %s is %.2f minutes old (minimum required: %d). "
                "Waiting %.2f minutes for alert to mature.",
                alert_id,
                elapsed_minutes,
                min_age,
                wait_minutes,
            )

            sleep(int(wait_minutes * 60))

            self.log.info(
                "Finished waiting for alert %s to mature.", alert_id
            )

        except Exception as err:
            self.log.error(
                "Failed to evaluate alert maturity for alert %s: %s",
                alert_id,
                err,
            )

    def get_indicators(self):
        """
        Retrieve unique indicators from Microsoft Defender for Endpoint
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/get-ti-indicators
        :exception: when indicators are not properly retrieved
        :return indicators: set of indicators
        """
        request_url = self.config.URL + "/api/indicators"
        indicators = set()
        try:
            response = self.retry_request(
                method="GET", url=request_url, headers=self.headers
            )
            json_response = response.json()
            if "error" in json_response:
                self.log.error(
                    "Failed to retrieve indicators - Error: %s"
                    % json_response["error"]["message"]
                )
            if "value" in json_response:
                for indicator in json_response["value"]:
                    indicators.add(indicator["indicatorValue"])
            else:
                self.log.error(
                    "Failed to retrieve indicators - Error: value key not found"
                )

        except Exception as err:
            self.log.error("Failed to retrieve indicators - Error %s" % err)

        self.log.info("%d unique indicator retrieved in total" % (len(indicators)))

        return indicators

    def create_indicator_objects(
        self, indicator_data, old_indicators, sample_url, evidence, sample_created_time
    ):
        """
        Create indicators objects based on VMRay Analyzer indicator data and retrieved indicators from Microsoft Defender for Endpoint
        :param indicator_data: dict of indicators which retrieved from VMRay submission
        :param old_indicators: set of indicators which retrieved from Microsoft Defender for Endpoint
        :param sample_url: Sample Web URL
        :param evidence: Evidence object
        :param sample_created_time: Sample creation time
        :return indicator_objects: list of indicator objects
        """

        indicator_objects = []
        alerts = ", ".join(evidence.alert_ids)
        generated_by = (
            evidence.sha256 if evidence.entity_type == "File" else evidence.url
        )
        description = (
            f"{INDICATOR.DESCRIPTION}\n"
            f"Alert ID: {alerts}\n"
            f"Generated By {evidence.entity_type} {generated_by}\n"
            f"Sample URL: {sample_url}\n"
            f"Created At: {sample_created_time}"
        )
        for key in indicator_data:
            if key in IOC_FIELD_MAPPINGS.keys():
                for indicator_field in IOC_FIELD_MAPPINGS[key]:
                    indicator_value = indicator_data[key]
                    for indicator in indicator_value:
                        if indicator[0] not in old_indicators:
                            expiration_date = (
                                datetime.now(timezone.utc)
                                + timedelta(days=int(INDICATOR.INDICATOREXPIRATION))
                            ).strftime("%Y-%m-%dT%H:%M:%SZ")
                            action = ""
                            if indicator_field in ["Url", "IpAddress", "DomainName"]:
                                action = (
                                    INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_IP_URL
                                    if indicator[1] == "malicious"
                                    else INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_IP_URL
                                )
                            elif indicator_field in [
                                "FileSha256",
                                "FileSha1",
                                "FileMd5",
                            ]:
                                action = (
                                    INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_FILE
                                    if indicator[1] == "malicious"
                                    else INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_FILE
                                )
                            indicator_objects.append(
                                Indicator(
                                    indicator_type=indicator_field,
                                    value=indicator[0],
                                    action=action,
                                    application=self.config.APPLICATION_NAME,
                                    title=INDICATOR.TITLE,
                                    description=description,
                                    verdict=indicator[1],
                                    expirationTime=expiration_date,
                                    generate_alert=INDICATOR.INDICATOR_ALERT,
                                )
                            )

        return indicator_objects

    def submit_indicators(self, indicators):
        """
        Submit indicators to Microsoft Defender for Endpoint
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/post-ti-indicator
        :param indicators: list of indicator objects
        :exception: when indicators are not submitted properly
        :return void:
        """
        self.log.info(
            "%d indicators submitting to Microsoft Defender for Endpoint"
            % len(indicators)
        )
        request_url = self.config.URL + "/api/indicators/import"
        try:
            for i in range(0, len(indicators), INDICATOR.MAX_TI_INDICATORS_PER_REQUEST):
                ind_to_submit = {
                    "Indicators": [
                        indicator.serialize()
                        for indicator in indicators[
                            i : i + INDICATOR.MAX_TI_INDICATORS_PER_REQUEST
                        ]
                    ]
                }
                response = self.retry_request(
                    method="POST",
                    url=request_url,
                    data=dumps(ind_to_submit),
                    headers=self.headers,
                )
                if response.ok:
                    self.log.info(
                        f"{len(indicators)} Indicators submitted successfully"
                    )
                else:
                    self.log.error(
                        "Failed to submit indicator - Error: %s" % response.content
                    )
        except Exception as err:
            self.log.error(f"Failed to submit indicators - Error: {err}")

    def update_incident(self, tags, incident_id):
        """
        Update incident tags
        """
        self.log.info("Adding tags to the incident id %s" % incident_id)
        try:
            # get tags from incident if any
            request_url = f"{self.config.SECURITY_GRAPH_API}/incidents/{incident_id}"

            incident_resp = self.retry_request(
                method="GET",
                url=request_url,
                headers=self.graph_headers,
            )
            if incident_resp.status_code != 200:
                self.log.error(
                    "Failed to Get incident %s - Error: %s"
                    % (incident_id, incident_resp.content)
                )
            else:
                incident_data = incident_resp.json()
                existing_tags = incident_data.get("customTags", [])
                self.log.info(f"Existing tags for incident {incident_id}: {existing_tags}")
                for tag in tags:
                    if tag not in existing_tags:
                        existing_tags.append(tag)
                tags = existing_tags


            #tags to have only one vmray verdict
            new_tags = [tag for tag in tags if "#VMRay" not in tag]
            if "#VMRay Malicious" in tags:
                new_tags.append("#VMRay Malicious")
            elif "#VMRay Suspicious" in tags:
                new_tags.append("#VMRay Suspicious")
            elif "#VMRay Clean" in tags:
                new_tags.append("#VMRay Clean")

                
           
            request_data = {"customTags": new_tags}
            self.log.info(f"Updating incident {incident_id} with tags: {new_tags}")

            response = self.retry_request(
                method="PATCH",
                url=request_url,
                data=dumps(request_data),
                headers=self.graph_headers,
            )

            if response.status_code != 200:
                self.log.error(
                    "Failed to update incident %s - Error: %s"
                    % (incident_id, response.content)
                )
            else:
                self.log.info(f"Successfully update incident {incident_id}")

        except Exception as err:
            self.log.error(
                "Failed to update incident %s - Error: %s" % (incident_id, err)
            )

    def create_comments(self, evidence, sample_data, sample_vtis, enrichment_sections):
        """
        Create comment to enrich alerts with VMRay Analyzer submission metadata
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/update-alert
        :param evidence: evidence object
        :param sample_data: dict object which contains summary data about the sample
        :param sample_vtis: dict object which contains parsed VTI data about the sample
        :param enrichment_sections: list
        :exception: when alert is not updated properly
        :return comment:
        """
        comment = ""
        self.log.info("Creating comment for alert enrichment")

        threat_names=sample_data.get("sample_threat_names", [])
        threat_names = [s for s in threat_names if not re.search(REMOVE_SPECIAL_CHAR, s) and not s.count('.')>1]

        if sample_data.get("sample_type") != "URL":
            comment = "Evidence SHA256:\n"
            comment += sample_data["sample_sha256hash"] + "\n\n"
        else:
            comment += "Evidence URL:\n"
            comment += evidence.url + "\n\n"
        

        if sample_data.get("sample_parent_sample_ids"):
            comment += "Child Sample of\n"
            comment += (
                "Sample IDs: "
                + ", ".join(map(str, sample_data.get("sample_parent_sample_ids") or []))
                + "\n\n"
            )


        comment += (
            ("VMRay Verdict: %s\n\n" % sample_data["sample_verdict"].upper())
            if sample_data["sample_verdict"]
            else "VMRay Verdict: N/A\n\n"
        )
        comment += "VMRay analysis" + " (" + sample_data["sample_created"][:10] + ")" +":\n"
        comment += (
            sample_data["sample_webif_url"]
            + "\n\n"
        )


        if (
            EnrichmentSectionTypes.CLASSIFICATIONS.value in enrichment_sections
            and sample_data["sample_classifications"]
        ):
            comment += "Classifications:\n"
            comment += "\n".join(sample_data["sample_classifications"]) + "\n\n"


        if (
            EnrichmentSectionTypes.THREAT_NAMES.value in enrichment_sections
            and threat_names
        ):
            comment += "Threat Names:\n"
            comment += "\n".join(threat_names) + "\n\n"


        if EnrichmentSectionTypes.VTIS.value in enrichment_sections and sample_vtis:
            comment += "VTI's:\n"
            comment += "\n".join(sample_vtis) + "\n\n"

        if len(comment) > 1000:
            comment = comment[:1000]

        return comment

    def enrich_alerts(self, evidence, sample_data, sample_vtis, enrichment_sections):
        """
        Enrich alerts with VMRay Analyzer submission metadata
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/update-alert
        :param evidence: evidence object
        :param sample_data: dict object which contains summary data about the sample
        :param sample_vtis: dict object which contains parsed VTI data about the sample
        :param enrichment_sections: list
        :exception: when alert is not updated properly
        :return void:
        """
        comment = ""
        if not sample_data.get("sample_parent_sample_ids"):
            comment = self.create_comments(
                evidence, sample_data, sample_vtis, enrichment_sections
            )
        elif (
            sample_data.get("sample_parent_sample_ids")
            and sample_data.get("sample_verdict") != "clean"
        ):
            comment = self.create_comments(
                evidence, sample_data, sample_vtis, enrichment_sections
            )
        if comment:
            if b64encode(comment.encode("utf-8")).decode("utf-8") not in evidence.comments:
                for alert_id in evidence.alert_ids:
                    try:
                        self.log.info(f"Adding comment to the alert id {alert_id}, comment: {comment}")

                        request_data = {
                            "@odata.type": "microsoft.graph.security.alertComment",
                            "comment": comment,
                        }
                        request_url = f"{self.config.SECURITY_GRAPH_API}/alerts_v2/{alert_id}/comments"
                        response = self.retry_request(
                            method="POST",
                            url=request_url,
                            data=dumps(request_data),
                            headers=self.graph_headers,
                        )

                        if response.status_code != 200:
                            self.log.error(
                                "Failed to update alert %s - Error: %s"
                                % (alert_id, response.content)
                            )
                        else:
                            self.log.info(f"Successfully update alert {alert_id}")

                    except Exception as err:
                        self.log.error(
                            "Failed to update alert %s - Error: %s" % (alert_id, err)
                        )
        else:
            self.log.info("No comment to add for alert enrichment")

    def enrich_incident(self, evidence, sample_data, sample_vtis, enrichment_sections):
        """
        Append a VMRay enrichment comment to the parent incident of the given evidence.
        Dedups against comments already present on the incident and against comments
        this process has already appended in the current run (per-instance cache).
        :param evidence: evidence object (must carry incident_id)
        :param sample_data: parsed VMRay sample data
        :param sample_vtis: parsed VMRay VTI data
        :param enrichment_sections: list of enrichment section toggles
        :return: void
        """
        incident_id = getattr(evidence, "incident_id", None)
        if not incident_id:
            return

        comment = ""
        if not sample_data.get("sample_parent_sample_ids"):
            comment = self.create_comments(
                evidence, sample_data, sample_vtis, enrichment_sections
            )
        elif (
            sample_data.get("sample_parent_sample_ids")
            and sample_data.get("sample_verdict") != "clean"
        ):
            comment = self.create_comments(
                evidence, sample_data, sample_vtis, enrichment_sections
            )

        if not comment:
            return

        existing = self._get_incident_comment_digests(incident_id)
        digest = b64encode(comment.encode("utf-8")).decode("utf-8")
        if digest in existing:
            self.log.info(
                f"Skipping incident {incident_id} comment - already present"
            )
            return

        if self.add_comment_to_incident(incident_id, comment):
            existing.add(digest)


    def _get_incident_comment_digests(self, incident_id):
        """
        Return (and lazily populate) the set of base64-encoded comment digests
        already attached to the given incident. Uses a per-instance cache so
        multiple evidences sharing an incident do not re-fetch or double-post.
        """
        if incident_id in self._incident_comment_cache:
            return self._incident_comment_cache[incident_id]

        digests = set()
        try:
            request_url = f"{self.config.SECURITY_GRAPH_API}/incidents/{incident_id}"
            response = self.retry_request(
                method="GET", url=request_url, headers=self.graph_headers
            )
            if response.status_code == 200:
                for item in response.json().get("comments", []) or []:
                    text = item.get("comment")
                    if text:
                        digests.add(
                            b64encode(text.encode("utf-8")).decode("utf-8")
                        )
            else:
                self.log.error(
                    "Failed to get incident %s for comment dedup - Error: %s"
                    % (incident_id, response.content)
                )
        except Exception as err:
            self.log.error(
                "Failed to get incident %s for comment dedup - Error: %s"
                % (incident_id, err)
            )

        self._incident_comment_cache[incident_id] = digests
        return digests


    def add_comment_to_incident(self, incident_id, comment):
        """
        Append a comment to an incident via the Microsoft Graph Security API
        sub-resource endpoint POST /incidents/{id}/comments. Each call posts
        exactly one alertComment; existing comments are preserved server-side.
        :param incident_id: Defender incident id
        :param comment: comment body
        :return: True on success, False otherwise
        """
        if not comment:
            return False
        try:
            request_url = f"{self.config.SECURITY_GRAPH_API}/incidents/{incident_id}/comments"
            request_data = {
                "@odata.type": "microsoft.graph.security.alertComment",
                "comment": comment,
            }
            response = self.retry_request(
                method="POST",
                url=request_url,
                data=dumps(request_data),
                headers=self.graph_headers,
            )
            if response.status_code not in (200, 204):
                self.log.error(
                    "Failed to update incident %s with comment - Error: %s"
                    % (incident_id, response.content)
                )
                return False
            self.log.info(f"Successfully added comment to incident {incident_id}")
            return True
        except Exception as err:
            self.log.error(
                "Failed to update incident %s with comment - Error: %s"
                % (incident_id, err)
            )
            return False

    def add_comment_to_alert(self, alert_id, comment):
        """ """
        try:
            self.log.info(f"Adding comment to the alert id {alert_id}, comment: {comment}")
            request_data = {
                "@odata.type": "microsoft.graph.security.alertComment",
                "comment": comment,
            }
            request_url = (
                f"{self.config.SECURITY_GRAPH_API}/alerts_v2/{alert_id}/comments"
            )
            response = self.retry_request(
                method="POST",
                url=request_url,
                data=dumps(request_data),
                headers=self.graph_headers,
            )
            if response.status_code != 200:
                self.log.error(
                    "Failed to update alert %s - Error: %s"
                    % (alert_id, response.content)
                )
            else:
                self.log.info(f"Successfully update alert {alert_id}")

        except Exception as err:
            self.log.error("Failed to update alert %s - Error: %s" % (alert_id, err))

    def retry_request(
        self,
        method,
        url,
        retries=DEFENDER_API.DEFENDER_API_RETRY,
        backoff=DEFENDER_API.DEFENDER_API_TIMEOUT,
        param=None,
        headers=None,
        data=None,
        stream=None,
        auth=False,
    ):
        """
        Retries the given API request in case of server errors or rate-limiting (HTTP 5xx or 429).

        :param method: HTTP method (GET, POST, etc.)
        :param url: URL to make the request to
        :param retries: Number of retry attempts
        :param backoff: backoff time in seconds
        :param headers: Headers to pass with the request
        :param param: Data to pass with the request (if applicable, e.g., for POST requests)
        :param data: Request body
        :param stream: Stream
        :param auth: Weather response from login api or from security api.
        :return: Response object from the request or None if it fails after retries
        """
        attempt = 0
        while attempt <= retries:
            try:
                response = requests.request(
                    method, url, params=param, headers=headers, data=data, stream=stream
                )
                response.raise_for_status()
                return response
            except requests.HTTPError as herr:
                if attempt < retries:
                    if response.status_code == AUTH_ERROR_STATUS_CODE:
                        self.authenticate_graph()
                        self.authenticate()
                        continue
                    if response.status_code in RETRY_STATUS_CODE:
                        self.log.warning(
                            f"Attempt {attempt + 1}: Server error or too many requests. Retrying..."
                        )
                        sleep(backoff // retries)
                        attempt += 1
                        continue
                    json_response = response.json()
                    if auth:
                        err_msg = f"{json_response.get('error')}: {json_response.get('error_description')}"
                    else:
                        err_msg = json_response.get("error", {}).get("message", "")
                    self.log.error(f"Error In Defender API calling: {err_msg}")
                    raise Exception(
                        "An error occurred during MicrosoftDefender Retry Request"
                    ) from herr
                self.log.error(f"Request failed after {retries} retries. Error: {herr}")
                raise Exception(
                    "An error occurred during MicrosoftDefender Retry Request"
                ) from herr
            except requests.ConnectionError as cerr:
                if attempt < retries:
                    self.log.warning(
                        f"Attempt {attempt + 1}: Request Connection error or too many requests. Retrying..."
                    )
                    sleep(backoff // retries)
                    attempt += 1
                    continue
                raise Exception(
                    "An error occurred during MicrosoftDefender Retry Request"
                ) from cerr
            except Exception as err:
                raise Exception(
                    "An error occurred during MicrosoftDefender Retry Request"
                ) from err
        raise Exception("Failed to complete microsoft request after multiple retries.")
