"""
Microsoft Defender Class
"""

from base64 import b64encode
from datetime import datetime, timedelta, timezone
from json import JSONDecodeError, dumps
from time import sleep
import re

import requests

from ..const import (
    AUTH_ERROR_STATUS_CODE,
    DEFENDER_API,
    INDICATOR,
    IOC_FIELD_MAPPINGS,
    RETRY_STATUS_CODE,
    EnrichmentSectionTypes,
    state,
    REMOVE_SPECIAL_CHAR,
)
from .Models import Evidence, Indicator

# pylint: disable=line-too-long
# pylint: disable=consider-using-f-string


class MicrosoftDefender:
    """
    Wrapper class for Microsoft Defender for Endpoint API calls
    Import this class to retrieve alerts, evidences and start live response jobs
    """

    def __init__(self, log):
        """
        Initialize and authenticate the MicrosoftDefender instance,
        use MicrosoftDefenderConfig as configuration
        :param log: logger instance
        :return: void
        """
        self.access_token = None
        self.headers = None
        self.graph_headers = None
        self.config = DEFENDER_API
        self.log = log
        self.authenticate_graph()
        self.authenticate()

    def authenticate(self):
        """
        Authenticate using Azure Active Directory application properties,
        and retrieves the access token
        :raise: Exception when credentials/application properties are not properly configured
        :return: void
        """

        body = {
            "resource": self.config.RESOURCE_APPLICATION_ID_URI,
            "client_id": self.config.APPLICATION_ID,
            "client_secret": self.config.APPLICATION_SECRET,
            "grant_type": "client_credentials",
        }
        try:
            response = self.retry_request(
                method="POST", url=self.config.AUTH_SEC_URL, data=body, auth=True
            )
            data = response.json()
            self.access_token = data["access_token"]
            self.headers = {
                "Authorization": "Bearer %s" % self.access_token,
                "User-Agent": self.config.USER_AGENT,
                "Content-Type": "application/json",
            }
            self.log.info(
                "Successfully authenticated the Microsoft Defender for Endpoint API"
            )
        except Exception as err:
            self.log.error(err)
            raise

    def authenticate_graph(self):
        """
        Authenticate using Azure Active Directory application properties,
        and retrieves the access token
        :raise: Exception when credentials/application properties are not properly configured
        :return: void
        """

        body = {
            "client_id": self.config.APPLICATION_ID,
            "scope": "https://graph.microsoft.com/.default",
            "client_secret": self.config.APPLICATION_SECRET,
            "grant_type": "client_credentials",
        }
        try:
            response = self.retry_request(
                method="POST", url=self.config.AUTH_URL, data=body, auth=True
            )
            data = response.json()
            self.access_token = data["access_token"]
            self.graph_headers = {
                "Authorization": "Bearer %s" % self.access_token,
                "User-Agent": self.config.USER_AGENT,
                "Content-Type": "application/json",
            }
            self.log.info(
                "Successfully authenticated the Microsoft Defender for Office365"
            )
        except Exception as err:
            self.log.error(err)
            raise

    def get_mdo_urls(self, alert_id: str) -> list:
        """
        Fetch MDO alert evidence
        alert_id: Alert ID of the alert.
        """
        query = dumps(
            {
                "Query": f"let alertId='{alert_id}'; let Msg=AlertEvidence | "
                f"where AlertId == alertId and isnotempty(NetworkMessageId) | "
                f"distinct NetworkMessageId, AlertId; let FromEvidence=AlertEvidence | "
                f"where AlertId == alertId and EntityType == 'Url' and isnotempty(RemoteUrl) | "
                f"project Timestamp, AlertId, Source='AlertEvidence', Url=RemoteUrl;"
                f" let FromClicks=UrlClickEvents | join kind=inner (Msg) on NetworkMessageId | "
                f"extend chain=todynamic(column_ifexists('UrlChain', dynamic(null))) | "
                f"project Timestamp, AlertId, Source='UrlClickEvents', Url, FinalUrl=iif(isnull(chain)"
                f" or array_length(chain)==0, Url, tostring(chain[array_length(chain)-1]));"
                f" let FromEmail=EmailUrlInfo | join kind=inner (Msg) on NetworkMessageId | "
                f"project Timestamp, AlertId, Source='EmailUrlInfo', Url, FinalUrl=Url; "
                f"union FromEvidence, FromClicks, FromEmail | "
                f"summarize FirstSeen=min(Timestamp) by AlertId, Source, Url, FinalUrl | order by FirstSeen desc",
                "Timespan": "P30D",
            }
        )
        request_url = f"{self.config.SECURITY_GRAPH_API}/runHuntingQuery"
        try:
            max_attempts = 6
            attempt = 0
            results = []

            while attempt < max_attempts:
                attempt += 1
                response = self.retry_request(
                    method="POST",
                    url=request_url,
                    headers={**self.graph_headers},
                    data=query,
                )

                try:
                    results = response.json().get("results", [])
                except (JSONDecodeError, ValueError) as e:
                    self.log.warning("JSON error on attempt %d: %s", attempt, e)
                    results = []

                if results:
                    break

                if attempt <= max_attempts:
                    self.log.info(
                        "No results (attempt %d/%d). Retrying in 30s...",
                        attempt,
                        max_attempts,
                    )
                    sleep(30)

            # Final failure
            if not results:
                self.add_comment_to_alert(alert_id, "No Url Found")

            self.log.info("length of results urls %d", len(results))
            urls = {
                item.get("Url")
                for item in results
                if isinstance(item, dict) and item.get("Url")
            }
            return list(urls)

        except Exception as err:
            self.log.error("Exception while retrieving alert %s: %s", alert_id, err)
            return []

    def get_evidences(self, last_run):
        """
        Retrieve alerts and related evidence information
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/get-alerts
        :exception: when alerts and evidences are not properly retrieved
        :return last_run: Datetime
        """
        odata_query = f"$filter=serviceSource eq 'microsoftDefenderForOffice365' and createdDateTime ge {last_run}"
        request_url = f"{self.config.SECURITY_GRAPH_API}/alerts_v2?{odata_query}"
        updated_last_run = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")
        evidences: dict = {}
        try:
            response = self.retry_request(
                method="GET", url=request_url, headers=self.graph_headers
            )
            json_response = response.json()

            if not json_response:
                self.log.error(
                    "Failed to parse api response - Error: value key not found in dict."
                )
                return evidences

            if "error" in json_response:
                self.log.error(
                    "Failed to retrieve alerts - Error: %s"
                    % json_response["error"]["message"]
                )
                return evidences
            state.post(updated_last_run)
            raw_alerts = json_response.get("value", [])
            self.log.info("%d alerts are fetched" % len(raw_alerts))
            alert_ids = []
            for raw_alert in raw_alerts:
                url_list = self.get_mdo_urls(raw_alert.get("id"))
                alert_ids.append(raw_alert["id"])
                for url in url_list:
                    evidence_obj = evidences.get(url) or Evidence(
                        alert_id=raw_alert["id"],
                        incident_id=raw_alert["incidentId"],
                        url=url,
                        entity_type="Url",
                    )
                    evidence_obj.alert_ids.add(raw_alert["id"])
                    evidence_obj.set_comments(raw_alert.get("comments", []))
                    evidences[url] = evidence_obj
            if alert_ids:
                self.log.info("Alert IDs are: %s", ", ".join(alert_ids))
        except Exception as err:
            self.log.error("Exception while retrieving alert %s", err)

        return evidences, updated_last_run

    def get_indicators(self):
        """
        Retrieve unique indicators from Microsoft Defender for Endpoint
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/get-ti-indicators
        :exception: when indicators are not properly retrieved
        :return indicators: set of indicators
        """
        request_url = self.config.URL + "/api/indicators"
        indicators = set()
        try:
            response = self.retry_request(
                method="GET", url=request_url, headers=self.headers
            )
            json_response = response.json()
            if "error" in json_response:
                self.log.error(
                    "Failed to retrieve indicators - Error: %s"
                    % json_response["error"]["message"]
                )
            if "value" in json_response:
                for indicator in json_response["value"]:
                    indicators.add(indicator["indicatorValue"])
            else:
                self.log.error(
                    "Failed to retrieve indicators - Error: value key not found"
                )

        except Exception as err:
            self.log.error("Failed to retrieve indicators - Error %s" % err)

        self.log.info("%d unique indicator retrieved in total" % (len(indicators)))

        return indicators

    def create_indicator_objects(
        self, indicator_data, old_indicators, sample_url, evidence, sample_created_time
    ):
        """
        Create indicators objects based on VMRay Analyzer indicator data and retrieved indicators from Microsoft Defender for Endpoint
        :param indicator_data: dict of indicators which retrieved from VMRay submission
        :param old_indicators: set of indicators which retrieved from Microsoft Defender for Endpoint
        :param sample_url: Sample Web URL
        :param evidence: Evidence object
        :param sample_created_time: Sample creation time
        :return indicator_objects: list of indicator objects
        """

        indicator_objects = []
        alerts = ", ".join(evidence.alert_ids)
        generated_by = (
            evidence.sha256 if evidence.entity_type == "File" else evidence.url
        )
        description = (
            f"{INDICATOR.DESCRIPTION}\n"
            f"Alert ID: {alerts}\n"
            f"Generated By {evidence.entity_type} {generated_by}\n"
            f"Sample URL: {sample_url}\n"
            f"Created At: {sample_created_time}"
        )
        for key in indicator_data:
            if key in IOC_FIELD_MAPPINGS.keys():
                for indicator_field in IOC_FIELD_MAPPINGS[key]:
                    indicator_value = indicator_data[key]
                    for indicator in indicator_value:
                        if indicator[0] not in old_indicators:
                            expiration_date = (
                                datetime.now(timezone.utc)
                                + timedelta(days=int(INDICATOR.INDICATOREXPIRATION))
                            ).strftime("%Y-%m-%dT%H:%M:%SZ")
                            action = ""
                            if indicator_field in ["Url", "IpAddress", "DomainName"]:
                                action = (
                                    INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_IP_URL
                                    if indicator[1] == "malicious"
                                    else INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_IP_URL
                                )
                            elif indicator_field in [
                                "FileSha256",
                                "FileSha1",
                                "FileMd5",
                            ]:
                                action = (
                                    INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_MALICIOUS_FILE
                                    if indicator[1] == "malicious"
                                    else INDICATOR.DEFENDER_INDICATOR_ACTION_FOR_SUSPICIOUS_FILE
                                )
                            indicator_objects.append(
                                Indicator(
                                    indicator_type=indicator_field,
                                    value=indicator[0],
                                    action=action,
                                    application=self.config.APPLICATION_NAME,
                                    title=INDICATOR.TITLE,
                                    description=description,
                                    verdict=indicator[1],
                                    expirationTime=expiration_date,
                                    generate_alert=INDICATOR.INDICATOR_ALERT,
                                )
                            )

        return indicator_objects

    def submit_indicators(self, indicators):
        """
        Submit indicators to Microsoft Defender for Endpoint
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/post-ti-indicator
        :param indicators: list of indicator objects
        :exception: when indicators are not submitted properly
        :return void:
        """
        self.log.info(
            "%d indicators submitting to Microsoft Defender for Endpoint"
            % len(indicators)
        )
        request_url = self.config.URL + "/api/indicators/import"
        try:
            for i in range(0, len(indicators), INDICATOR.MAX_TI_INDICATORS_PER_REQUEST):
                ind_to_submit = {
                    "Indicators": [
                        indicator.serialize()
                        for indicator in indicators[
                            i : i + INDICATOR.MAX_TI_INDICATORS_PER_REQUEST
                        ]
                    ]
                }
                response = self.retry_request(
                    method="POST",
                    url=request_url,
                    data=dumps(ind_to_submit),
                    headers=self.headers,
                )
                if response.ok:
                    self.log.info(
                        f"{len(indicators)} Indicators submitted successfully"
                    )
                else:
                    self.log.error(
                        "Failed to submit indicator - Error: %s" % response.content
                    )
        except Exception as err:
            self.log.error(f"Failed to submit indicators - Error: {err}")

    def update_incident(self, tags, incident_id):
        """
        Update incident tags
        """
        self.log.info("Adding tags to the incident id %s" % incident_id)
        try:
            # get tags from incident if any
            request_url = f"{self.config.SECURITY_GRAPH_API}/incidents/{incident_id}"

            incident_resp = self.retry_request(
                method="GET",
                url=request_url,
                headers=self.graph_headers,
            )
            if incident_resp.status_code != 200:
                self.log.error(
                    "Failed to Get incident %s - Error: %s"
                    % (incident_id, incident_resp.content)
                )
            else:
                incident_data = incident_resp.json()
                existing_tags = incident_data.get("customTags", [])
                for tag in tags:
                    if tag not in existing_tags:
                        existing_tags.append(tag)
                tags = existing_tags

            request_data = {"customTags": tags}
            response = self.retry_request(
                method="PATCH",
                url=request_url,
                data=dumps(request_data),
                headers=self.graph_headers,
            )

            if response.status_code != 200:
                self.log.error(
                    "Failed to update incident %s - Error: %s"
                    % (incident_id, response.content)
                )
            else:
                self.log.info(f"Successfully update incident {incident_id}")

        except Exception as err:
            self.log.error(
                "Failed to update incident %s - Error: %s" % (incident_id, err)
            )

    def create_comments(self, evidence, sample_data, sample_vtis, enrichment_sections):
        """
        Create comment to enrich alerts with VMRay Analyzer submission metadata
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/update-alert
        :param evidence: evidence object
        :param sample_data: dict object which contains summary data about the sample
        :param sample_vtis: dict object which contains parsed VTI data about the sample
        :param enrichment_sections: list
        :exception: when alert is not updated properly
        :return comment:
        """
        comment = ""

        threat_names=sample_data.get("sample_threat_names", [])
        threat_names = [s for s in threat_names if not re.search(REMOVE_SPECIAL_CHAR, s)]

        if sample_data.get("sample_type") != "URL":
            comment = "Evidence SHA256:\n"
            comment += sample_data["sample_sha256hash"] + "\n\n"
        else:
            comment += "Evidence URL:\n"
            comment += evidence.url + "\n\n"

        if sample_data.get("sample_parent_sample_ids"):
            comment += "Child Sample of\n"
            comment += (
                "Sample IDs: "
                + ", ".join(map(str, sample_data.get("sample_parent_sample_ids") or []))
                + "\n\n"
            )
        comment += (
            ("VMRay Verdict: %s\n\n" % sample_data["sample_verdict"].upper())
            if sample_data["sample_verdict"]
            else "VMRay Verdict: N/A\n\n"
        )
        comment += "VMRay analysis" + " (" + sample_data["sample_created"][:10] + ")" +":\n"
        comment += (
            sample_data["sample_webif_url"]
            + "\n\n"
        )

        if (
            EnrichmentSectionTypes.CLASSIFICATIONS.value in enrichment_sections
            and sample_data["sample_classifications"]
        ):
            comment += "Classifications:\n"
            comment += "\n".join(sample_data["sample_classifications"]) + "\n\n"

        if (
            EnrichmentSectionTypes.THREAT_NAMES.value in enrichment_sections
            and threat_names
        ):
            comment += "Threat Names:\n"
            comment += "\n".join(threat_names) + "\n\n"

        if EnrichmentSectionTypes.VTIS.value in enrichment_sections and sample_vtis:
            comment += "VTI's:\n"
            comment += "\n".join(sample_vtis) + "\n\n"
        if len(comment) > 1000:
            comment = comment[:1000]
        return comment

    def enrich_alerts(self, evidence, sample_data, sample_vtis, enrichment_sections):
        """
        Enrich alerts with VMRay Analyzer submission metadata
        https://docs.microsoft.com/en-us/microsoft-365/security/defender-endpoint/update-alert
        :param evidence: evidence object
        :param sample_data: dict object which contains summary data about the sample
        :param sample_vtis: dict object which contains parsed VTI data about the sample
        :param enrichment_sections: list
        :exception: when alert is not updated properly
        :return void:
        """
        comment = ""
        if not sample_data.get("sample_parent_sample_ids"):
            comment = self.create_comments(
                evidence, sample_data, sample_vtis, enrichment_sections
            )
        elif (
            sample_data.get("sample_parent_sample_ids")
            and sample_data.get("sample_verdict") != "clean"
        ):
            comment = self.create_comments(
                evidence, sample_data, sample_vtis, enrichment_sections
            )
        if b64encode(comment.encode("utf-8")).decode("utf-8") not in evidence.comments:
            for alert_id in evidence.alert_ids:
                try:
                    request_data = {
                        "@odata.type": "microsoft.graph.security.alertComment",
                        "comment": comment,
                    }
                    request_url = f"{self.config.SECURITY_GRAPH_API}/alerts_v2/{alert_id}/comments"
                    response = self.retry_request(
                        method="POST",
                        url=request_url,
                        data=dumps(request_data),
                        headers=self.graph_headers,
                    )

                    if response.status_code != 200:
                        self.log.error(
                            "Failed to update alert %s - Error: %s"
                            % (alert_id, response.content)
                        )
                    else:
                        self.log.info(f"Successfully update alert {alert_id}")

                except Exception as err:
                    self.log.error(
                        "Failed to update alert %s - Error: %s" % (alert_id, err)
                    )

    def add_comment_to_alert(self, alert_id, comment):
        """ """
        try:
            request_data = {
                "@odata.type": "microsoft.graph.security.alertComment",
                "comment": comment,
            }
            request_url = (
                f"{self.config.SECURITY_GRAPH_API}/alerts_v2/{alert_id}/comments"
            )
            response = self.retry_request(
                method="POST",
                url=request_url,
                data=dumps(request_data),
                headers=self.graph_headers,
            )
            if response.status_code != 200:
                self.log.error(
                    "Failed to update alert %s - Error: %s"
                    % (alert_id, response.content)
                )
            else:
                self.log.info(f"Successfully update alert {alert_id}")

        except Exception as err:
            self.log.error("Failed to update alert %s - Error: %s" % (alert_id, err))

    def retry_request(
        self,
        method,
        url,
        retries=DEFENDER_API.DEFENDER_API_RETRY,
        backoff=DEFENDER_API.DEFENDER_API_TIMEOUT,
        param=None,
        headers=None,
        data=None,
        stream=None,
        auth=False,
    ):
        """
        Retries the given API request in case of server errors or rate-limiting (HTTP 5xx or 429).

        :param method: HTTP method (GET, POST, etc.)
        :param url: URL to make the request to
        :param retries: Number of retry attempts
        :param backoff: backoff time in seconds
        :param headers: Headers to pass with the request
        :param param: Data to pass with the request (if applicable, e.g., for POST requests)
        :param data: Request body
        :param stream: Stream
        :param auth: Weather response from login api or from security api.
        :return: Response object from the request or None if it fails after retries
        """
        attempt = 0
        while attempt <= retries:
            try:
                response = requests.request(
                    method, url, params=param, headers=headers, data=data, stream=stream
                )
                response.raise_for_status()
                return response
            except requests.HTTPError as herr:
                if attempt < retries:
                    if response.status_code == AUTH_ERROR_STATUS_CODE:
                        self.authenticate_graph()
                        self.authenticate()
                        continue
                    if response.status_code in RETRY_STATUS_CODE:
                        self.log.warning(
                            f"Attempt {attempt + 1}: Server error or too many requests. Retrying..."
                        )
                        sleep(backoff // retries)
                        attempt += 1
                        continue
                    json_response = response.json()
                    if auth:
                        err_msg = f"{json_response.get('error')}: {json_response.get('error_description')}"
                    else:
                        err_msg = json_response.get("error", {}).get("message", "")
                    self.log.error(f"Error In Defender API calling: {err_msg}")
                    raise Exception(
                        "An error occurred during MicrosoftDefender Retry Request"
                    ) from herr
                self.log.error(f"Request failed after {retries} retries. Error: {herr}")
                raise Exception(
                    "An error occurred during MicrosoftDefender Retry Request"
                ) from herr
            except requests.ConnectionError as cerr:
                if attempt < retries:
                    self.log.warning(
                        f"Attempt {attempt + 1}: Request Connection error or too many requests. Retrying..."
                    )
                    sleep(backoff // retries)
                    attempt += 1
                    continue
                raise Exception(
                    "An error occurred during MicrosoftDefender Retry Request"
                ) from cerr
            except Exception as err:
                raise Exception(
                    "An error occurred during MicrosoftDefender Retry Request"
                ) from err
        raise Exception("Failed to complete microsoft request after multiple retries.")
