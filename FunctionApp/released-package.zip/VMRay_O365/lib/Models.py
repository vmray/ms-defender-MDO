"""Models"""

from base64 import b64encode
from dataclasses import dataclass, field
from typing import Any
from io import BytesIO

from ..const import MS_DEFENDER_SEVERITY_MAPPING


@dataclass
class Evidence:
    """
    Evidence class for storing evidence related information
    """
    # Mandatory fields (no defaults)
    alert_id: str
    incident_id: str
    entity_type: str

    # Optional fields (with defaults)
    url: str = ""
    sample_id: str = ""
    sha256: str = ""
    file: BytesIO | None = None
    vmray_sample: dict = field(default_factory=dict)
    comments: set[str] = field(default_factory=set)
    submissions: list = field(default_factory=list)

    def __post_init__(self):
        self.alert_ids = {self.alert_id}

    def set_comments(self, comments):
        for comment in comments:
            if "comment" in comment and comment["comment"] is not None:
                self.comments.add(
                    b64encode(comment["comment"].encode("utf-8")).decode("utf-8")
                )


@dataclass
class Indicator:
    """
    Indicator class for storing indicator related data
    """

    indicator_type: str
    value: Any
    action: str
    application: str
    title: str
    description: str
    verdict: str
    expirationTime: str
    generate_alert: bool = field(default=True)

    def __post_init__(self):
        # Adjust the verdict based on the MS_DEFENDER_SEVERITY_MAPPING
        self.verdict = MS_DEFENDER_SEVERITY_MAPPING.get(self.verdict)

        # Set generate_alert based on the action value
        if self.action == "Audit":
            self.generate_alert = True
        else:
            self.generate_alert = self.generate_alert

    def serialize(self):
        """
        Serialize indicator object as dict
        Used for posting indicator objects with API request
        :return dict: serialized indicator data
        """
        return {
            "indicatorType": self.indicator_type,
            "indicatorValue": self.value,
            "action": self.action,
            "application": self.application,
            "title": self.title,
            "description": self.description,
            "severity": self.verdict,
            "expirationTime": self.expirationTime,
            "generateAlert": self.generate_alert,
        }
