"""
Main file for azure function execution
"""

import logging as log
import traceback
from datetime import datetime, timedelta, timezone
from typing import Optional
import re

import azure.functions as func

from .const import INDICATOR, AVEnrichment, EDREnrichment, VMRay_CONFIG, state, REMOVE_SPECIAL_CHAR
from .lib.MicrosoftDefender import MicrosoftDefender
from .lib.Models import Evidence
from .lib.VMRay import VMRay


def run(last_run) -> str:
    """
    :param last_run:
    :return: str
    """
    ms_defender = MicrosoftDefender(log)
    vmray = VMRay(log)
    found_evidences, download_url_evidences, resubmit_url_evidences = {}, {}, {}
    submissions = []

    evidences, updated_last_run = ms_defender.get_evidences(last_run)
    for key, evidence in evidences.items():
        sample = ""
        existing_sub = vmray.get_submission_by_query(key)
        if len(existing_sub) > 0:
            sample_id = existing_sub[0].get("submission_sample_id")
            sample = vmray.get_sample(sample_id, True)
        if sample:
            evidence_metadata = vmray.parse_sample_data(sample)
            evidence.sample_id = evidence_metadata["sample_id"]
            resubmit = sample_age(
                existing_sub[0]["submission_created"], VMRay_CONFIG.RESUBMIT
            )
            if (
                resubmit
                and evidence_metadata["sample_verdict"]
                in VMRay_CONFIG.RESUBMISSION_VERDICTS
            ):
                log.info(
                    "Resubmit is set to true, %s will be resubmitted to VMRay for analysis.",
                    key,
                )
                resubmit_url_evidences[key] = evidence
            else:
                log.info("Resubmit is set to False. No need to submit again.")
                evidences[key].vmray_sample = sample
                found_evidences[key] = evidences[key]
        else:
            log.info("sample results for %s does not exist in VMRay.", key)
            log.info("%s will be downloaded and submitted to VMRay for analysis.", key)
            download_url_evidences[key] = evidence

    if found_evidences:
        for evidence in found_evidences.values():
            sample_data = vmray.parse_sample_data(evidence.vmray_sample)
            # if sample_data["sample_verdict"] in GENERAL_CONFIG.SELECTED_VERDICTS:
            child_sample_id = vmray.get_child_samples(sample_data)
            if INDICATOR.ACTIVE:
                indicator_objects = process_indicators(
                    vmray, ms_defender, child_sample_id, evidence
                )
                if indicator_objects:
                    ms_defender.submit_indicators(indicator_objects)
                else:
                    log.info("No IOC found in vmray to submit")
            if AVEnrichment.ACTIVE.value or EDREnrichment.ACTIVE.value:
                enrich_alerts(vmray, ms_defender, evidence, child_sample_id)

    download_url_evidences.update(resubmit_url_evidences)

    if download_url_evidences:
        log.info("Alert evidence type URLs are being processed..")
        submissions.extend(process_url(download_url_evidences, vmray, ""))
    process_submissions(vmray, ms_defender, submissions, True)
    if VMRay_CONFIG.VMRAY_INCIDENT_TAGS:
        process_incident(evidences, vmray, ms_defender)
    return updated_last_run


def process_incident(evidences, vmray, ms_defender):
    """ """
    incident_dict = {}
    for _, evidence in evidences.items():
        incident_dict.setdefault(evidence.incident_id, set()).add(evidence.sample_id)
    for inc_id, sample_ids in incident_dict.items():
        found_malicious = False
        found_suspicious = False
        threat_families = []
        tags = []
        child_sample_objects = []
        for s_id in sample_ids:
            sample_data = vmray.get_sample(s_id, True)
            sample_data = vmray.parse_sample_data(sample_data)

            #sample child threat names
            child_samples = vmray.get_child_samples(sample_data)
            for child_id in child_samples:
                child_sample = vmray.get_sample(child_id, True)
                child_sample_parsed = vmray.parse_sample_data(child_sample)
                child_sample_objects.append(child_sample_parsed)
            for x in child_sample_objects:
                if x and x.get("sample_verdict") != "clean":
                    threat_families.extend(x.get("sample_threat_names", []))

            if sample_data and sample_data.get("sample_verdict") == "malicious":
                found_malicious = True
            if sample_data and sample_data.get("sample_verdict") == "suspicious":
                found_suspicious = True
            threat_families.extend(sample_data.get("sample_threat_names", []))
        if found_malicious:
            verdict = "#VMRay Malicious"
        elif found_suspicious:
            verdict = "#VMRay Suspicious"
        else:
            verdict = "#VMRay Clean"

        #remove special characters from threat family names
        threat_families = [s for s in threat_families if not re.search(REMOVE_SPECIAL_CHAR, s)]

        tags.append(verdict)
        tags.extend(threat_families)
        tags = list(set(tags))
        ms_defender.update_incident(tags, inc_id)
    return


def sample_age(created_date: str, resubmit_after: str):
    """
    Function to calculate sample submission time period
    """
    if resubmit_after == 0:
        return True

    sample_created = datetime.fromisoformat(created_date)
    if sample_created.tzinfo is None:
        sample_created = sample_created.replace(tzinfo=timezone.utc)
    current_date = datetime.now(timezone.utc)
    last_submission = current_date - sample_created
    return last_submission >= timedelta(days=int(resubmit_after))


def process_url(download_evidences: dict, vmray: VMRay, threat_family: str) -> list:
    log.info(
        "In total, %d URL evidences needs to be downloaded and submitted to VMRay.",
        len(download_evidences),
    )
    url_submission = vmray.submit_url(download_evidences, threat_family)
    return url_submission


def enrich_alerts(vmray, ms_defender, evidence, child_sample_id):
    """
    :param vmray: VMRay Object
    :param ms_defender: Microsoft Object
    :param evidence: Evidences
    :param child_sample_id: Child Sample ID
    :return: None
    """
    for child_id in child_sample_id:
        vti_data = vmray.get_sample_vtis(child_id)
        sample_vtis = vmray.parse_sample_vtis(vti_data)
        sample_details = vmray.get_sample(child_id, True)
        parse_sample_detail = vmray.parse_sample_data(sample_details)
        ms_defender.enrich_alerts(
            evidence,
            parse_sample_detail,
            sample_vtis,
            AVEnrichment.SELECTED_SECTIONS.value,
        )


def process_indicators(vmray, ms_defender, child_sample_id, evidence):
    """
    :param vmray: VMRay Object
    :param ms_defender: Microsoft Object
    :param child_sample_id: Child Sample ID
    :param evidence: Evidence Object
    :return: List of indicator object
    """
    indicator_objects = []
    old_indicators = ms_defender.get_indicators()
    for child_id in child_sample_id:
        child_sample_data = vmray.get_sample(child_id, True)
        sample_url = child_sample_data.get("sample_webif_url")
        sample_created_time = child_sample_data.get("sample_created")
        sample_iocs = vmray.get_sample_iocs(child_id)
        ioc_data = vmray.parse_sample_iocs(sample_iocs)
        indicator_objects.extend(
            ms_defender.create_indicator_objects(
                ioc_data, old_indicators, sample_url, evidence, sample_created_time
            )
        )
    return indicator_objects


def process_submissions(vmray, ms_defender, submissions, is_enrich):
    """
    :param vmray: VMRay Object
    :param ms_defender: Microsoft Object
    :param submissions: Child Sample ID
    :param alert: Alert ID
    :param is_enrich: weather enrich the alert on not
    :return: None
    """
    for result in vmray.wait_submissions(submissions):
        submission = result["submission"]
        evidence = submission["evidence"]
        vmray.check_submission_error(submission)

        if result["finished"]:
            sample = vmray.get_sample(submission["sample_id"], True)
            sample_data = vmray.parse_sample_data(sample)

            # if sample_data["sample_verdict"] in GENERAL_CONFIG.SELECTED_VERDICTS:
            child_sample_id = vmray.get_child_samples(sample_data)
            if INDICATOR.ACTIVE:
                indicator_objects = process_indicators(
                    vmray, ms_defender, child_sample_id, evidence
                )

                if indicator_objects:
                    ms_defender.submit_indicators(indicator_objects)
                else:
                    log.info("No IOC found in vmray to submit")
            if is_enrich:
                enrich_alerts(vmray, ms_defender, evidence, child_sample_id)


def get_last_saved_timestamp() -> Optional[int]:
    """
    Retrieves the last saved Unix timestamp from persistent state.

    Checks the system state for the last recorded timestamp of a previous
    successful operation. If no timestamp exists (e.g., on the first run),
    returns None.

    Returns
    -------
    Optional[int]
        The Unix timestamp of the last saved run, or None if not available.
    """
    last_run_date_time = state.get()
    log.debug("Last saved timestamp is %s", last_run_date_time)

    return last_run_date_time if last_run_date_time else None


def main(mytimer: func.TimerRequest) -> None:
    """
    Main Function
    """
    if mytimer.past_due:
        log.info("The timer is past due!")
        return

    initial_date_time = get_last_saved_timestamp() or (
        datetime.now() - timedelta(seconds=int(VMRay_CONFIG.TIME_SPAN))
    ).strftime("%Y-%m-%dT%H:%M:%SZ")
    log.info(f"last_run {initial_date_time}")

    try:
        updated_last_run = run(initial_date_time)
        log.info(f"updated Last run {updated_last_run}")
    except Exception as ex:
        error_msg = traceback.format_exc()
        log.error("Exception Occurred: %s", str(ex))
        log.error(error_msg)
        state.post(initial_date_time)
